//function definitions
//********************
int *read_file(char *, int *, int);

int write_file(char *, int *, int);

int * master(int *, int*, int);

void slave();

int *algo_mul(int *, int *, int, int, int);



//preprocessor definitions
//************************
#define MAT_NORM 0
#define MAT_TURN 1
#define INFO_SIZE 3
